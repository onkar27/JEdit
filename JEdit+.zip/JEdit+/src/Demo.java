class Demo
{
	public static void main(String [] argv){
		System.out.println("This is my Editor !!");
	}
}