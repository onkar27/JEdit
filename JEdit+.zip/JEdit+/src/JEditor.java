import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.io.*;

class JEditor extends Frame implements ActionListener,FocusListener,WindowListener{
	
	private static final long serialVersionUID = 1L;
	Label NamePlate;
	String FileName,ClassName;
	TextArea textArea;
	Button bN,bO,bS,bC,bR,bE;
	Panel pan1,pan2 ;
	JEditor(){
		super("JEditor");

		addWindowListener(this);
		
		init();
		System.out.println("\nJEditor Initialized !");
		textArea = new TextArea();
		textArea.setPreferredSize(new Dimension(1300,600));
		textArea.requestFocus();

		NamePlate = new Label("JEdit+  By Onkar J. Sathe");
		bN = new Button("New");
		bO = new Button("Open");
		bS = new Button("Save");
		bC = new Button("Compile");
		bR = new Button("Run");
		bE = new Button("Exit");

		bN.setPreferredSize(new Dimension(150, 40));
		bO.setPreferredSize(new Dimension(150, 40));
		bS.setPreferredSize(new Dimension(150, 40));
		bC.setPreferredSize(new Dimension(150, 40));
		bR.setPreferredSize(new Dimension(150, 40));
		bE.setPreferredSize(new Dimension(150, 40));

		pan1 = new Panel();
		pan2 = new Panel();
		
		bN.addActionListener(this);
		bO.addActionListener(this);
		bS.addActionListener(this);
		bC.addActionListener(this);
		bR.addActionListener(this);
		bE.addActionListener(this);

		pan1.setLayout(new FlowLayout());
		pan1.add(NamePlate);
		pan1.add(bN);
		pan1.add(bO);//,BorderLayout.NORTH);
		pan1.add(bS);
		pan1.add(bC);
		pan1.add(bR);
		pan1.add(bE);
		textArea.setFont(new Font("Consolas", Font.BOLD, 16));
		textArea.setForeground(Color.CYAN);
		textArea.setBackground(new Color(31,29,29));
		pan2.add(textArea);
		
		setLayout(new FlowLayout());
		
		add(pan1);
		add(pan2);

		setSize(1360,760);
		setVisible(true);
	}  
	public void windowOpened(WindowEvent e){
	}
	public void windowClosed(WindowEvent e){
	}
	public void windowClosing(WindowEvent e){
		System.exit(0);
	}
	public void windowActivated(WindowEvent e){
	}
	public void windowDeactivated(WindowEvent e){
	}
	public void windowIconified(WindowEvent e){
	}	
	public void windowDeiconified(WindowEvent e){
	}
	void init(){
		ProcessBuilder compile = new ProcessBuilder("cmd");
		compile.redirectErrorStream(true);
		
		try{
		 compile.start();
		}
		catch(Exception k){
		}
	}
	public void actionPerformed(ActionEvent e){
		Button b = (Button)e.getSource();
		if(b == bN){
			textArea.setText("Type Here");
		}
		else if(b == bO){
			String data="";
			File file = null;
			JFileChooser fileChooser = new JFileChooser();
			int returnVal = fileChooser.showOpenDialog(null);
			
			if (returnVal == JFileChooser.APPROVE_OPTION) {
		        file = fileChooser.getSelectedFile();
		        JOptionPane.showMessageDialog(null,""+"File Opened SuccessFully !" + file.getName(),null, JOptionPane.INFORMATION_MESSAGE, null);
		    }
		     else{
		    	 JOptionPane.showMessageDialog(null,""+"Open command cancelled by user.",null, JOptionPane.INFORMATION_MESSAGE, null);  
		    	 return ;
		    }
		    
			//System.out.println("\nJEditor Initialized !");
		    data = "";
		    FileReader dis =null;
		    try{
		    	dis = new FileReader(file);
		    }
		    catch(Exception k){
		    }
		    int re=0;
		    while(true){
		    	try{
		    		re=dis.read();
		    		if(re==-1)
		    			break;
		    		data+=(char)re;
		    	}
		    	catch(Exception k){
		    		break;
		    	}
		    }
		    try{
		    	dis.close();
		    }
		    catch(Exception k){}

		    textArea.setText(data);
		    
		    FileName = file.getName();
		    ClassName = "";
		    int i = 0;
		    while(i<FileName.length()){
		    	if(FileName.charAt(i)=='.')
		    		break;
		    	ClassName +=""+ FileName.charAt(i);
		 		i++;
		    }
		}
		else if(b == bS){
			String data=textArea.getText();
			File file = null;
			JFileChooser fileChooser = new JFileChooser();
			int returnVal = fileChooser.showSaveDialog(null);
			
			if (returnVal == JFileChooser.APPROVE_OPTION) {
		        file = fileChooser.getSelectedFile();
		        JOptionPane.showMessageDialog(null,""+"File Saved SuccessFully !" + file.getName(),null, JOptionPane.INFORMATION_MESSAGE, null);
		    }
		     else{
		    	 JOptionPane.showMessageDialog(null,""+"Open command cancelled by user.",null, JOptionPane.INFORMATION_MESSAGE, null);  
		    	 return ;
		    }
		    try{	
		    FileWriter f = new FileWriter(file);
				 f.write(data);
				 f.close();
		    }
		    catch(Exception k){}
		    FileName = file.getName();
		    System.out.println(FileName);
		    ClassName = "";
		    int i = 0;
		    while(i<FileName.length()){
		    	if(FileName.charAt(i)=='.')
		    		break;
		    	ClassName +=""+ FileName.charAt(i);
		 		i++;
		    }
		}
		else if(b == bC){
			if(FileName == null){
				JOptionPane.showMessageDialog(null, "Please Save File");
				return ;
			}
			System.out.print("\nCompilation Results : ");
			int f = 0;
			ProcessBuilder compile = new ProcessBuilder("javac",FileName);
			compile.redirectErrorStream(true);
			Process p =null;
			try{
				p= compile.start();
			}
			catch(Exception k){
			}
			BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String l="";
			while(true){
				try{
					l = r.readLine();
				}
				catch(Exception k){
				}if(l == null)break;
				System.out.println(l);
				
				f = 1;	
			}
			if(f==0){
				System.out.println("Compiled SuccessFully");
			}
		}
		else if(b == bR){
			if(FileName == null){
				JOptionPane.showMessageDialog(null, "Please Save File");
				return ;
			}
			System.out.println("\nBuild Results : ");
			ProcessBuilder run = new ProcessBuilder("java",ClassName);
			run.redirectErrorStream(true);
			Process p =null;
			try{
				p= run.start();
			}
			catch(Exception k){
			}

			BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String l="";
			while(true){
				try{
					l = r.readLine();
				}
				catch(Exception k){
				}

				if(l == null)break;
				System.out.println(l);
			}
			
		}
		else if(b == bE)
			System.exit(0);
	}
	public void focusGained(FocusEvent e)
	{
	}
	public void focusLost(FocusEvent e)
	{
	}
	public static void main(String []argv){
		 new JEditor();
	}
}
